import os

# اسم الملف
filename = "your_file.py"

# 775 تعني: rwxrwxr-x
os.chmod(filename, 0o775)

print(f"تم تغيير صلاحيات {filename} إلى rwxrwxr-x")
