# File Permission Project

## 🎯 Objective
Understand file permissions in Unix/Linux systems and apply changes using Python.

## 📄 Flowchart
![](file_permission_flowchart.png)

## 🔧 Python Script
This script applies `chmod 775` to a file, giving it `rwxrwxr-x` permissions.

```python
import os

filename = "your_file.py"
os.chmod(filename, 0o775)
print(f"تم تغيير صلاحيات {filename} إلى rwxrwxr-x")
```

## 📝 Usage
1. Replace `"your_file.py"` with your actual file name.
2. Run the script on Linux/macOS or WSL.
